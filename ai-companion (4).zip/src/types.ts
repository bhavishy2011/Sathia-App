export interface Window {
  aistudio?: {
    hasSelectedApiKey: () => Promise<boolean>;
    openSelectKey: () => Promise<void>;
  }
}

declare global {
  interface Window {
    aistudio?: {
      hasSelectedApiKey: () => Promise<boolean>;
      openSelectKey: () => Promise<void>;
    }
  }
}

export interface UserProfile {
  name: string;
  age: string;
  education: string;
  isPremium?: boolean;
  theme?: string;
  chatBackgroundImage?: string;
  createdAt: number;
}

export interface Companion {
  id: string;
  userId: string;
  name: string;
  role: string;
  gender: 'boy' | 'girl' | 'other';
  nationality?: string;
  personality: string;
  interests: string;
  clothingStyle: string;
  clothing: string;
  clothingColor: string;
  hairstyle: string;
  hairColor: string;
  skinTone: string;
  eyes: string;
  height: string;
  glasses: boolean;
  avatarUrl?: string;
  createdAt: number;
  updatedAt: number;
}

export interface Message {
  id: string;
  userId: string;
  role: 'user' | 'model'; // Gemini models expect 'user' and 'model'
  text: string;
  timestamp: number;
  createdAt: number;
  reaction?: string;
}

