import React, { useState, useRef } from 'react';
import { Companion } from '../types';
import { ArrowLeft, Trash2, Heart, Pencil, Loader2, Save, Camera } from 'lucide-react';
import { motion } from 'motion/react';
import { updateCompanion } from '../services/db';
import { getAvatarUrl } from '../lib/avatars';

interface ProfileProps {
  companion: Companion;
  onBack: () => void;
  onReset: () => void;
}

export default function Profile({ companion, onBack, onReset }: ProfileProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(companion.name);
  const [personality, setPersonality] = useState(companion.personality);
  const [avatarUrlState, setAvatarUrlState] = useState(companion.avatarUrl || '');
  const [saving, setSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_SIZE = 400;
        let width = img.width;
        let height = img.height;
        
        if (width > height) {
          if (width > MAX_SIZE) {
            height *= MAX_SIZE / width;
            width = MAX_SIZE;
          }
        } else {
          if (height > MAX_SIZE) {
            width *= MAX_SIZE / height;
            height = MAX_SIZE;
          }
        }
        
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        
        const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.8);
        setAvatarUrlState(compressedDataUrl);
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleSave = async () => {
    if (!name.trim() || !personality.trim()) return;
    setSaving(true);
    try {
      await updateCompanion(companion.id, {
        name: name.trim(),
        personality: personality.trim(),
        avatarUrl: avatarUrlState
      });
      setIsEditing(false);
      // App component will reactively get the new companion via db subscription? No, we need a local state update or reload.
      // Easiest is location.reload() or we can pass a setCompanion update back.
      // Wait, we just update the db and hope onSnapshot catches it... wait we didn't implement onSnapshot for companion, we fetch it once in App.tsx!
      // I will just use location.reload() to make it simpler and reliable since it's a small app.
      window.location.reload();
    } catch (e) {
      alert("Failed to update profile");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="h-screen w-full flex flex-col bg-[#0F0F0F] relative">
      <header className="h-16 px-4 flex items-center justify-between border-b border-white/5 shrink-0 bg-[#0F0F0F] sticky top-0 z-10">
        <button 
          onClick={onBack}
          className="p-2 -ml-2 rounded-xl hover:bg-white/5 transition-colors text-slate-400 hover:text-slate-200"
        >
          <ArrowLeft size={20} />
        </button>
        <h2 className="text-sm font-semibold tracking-wide text-slate-100">Companion Profile</h2>
        <div className="w-10"></div>
      </header>

      <main className="flex-1 p-6 overflow-y-auto space-y-6 max-w-md mx-auto w-full">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#151515] border border-white/5 rounded-3xl p-6 text-center flex flex-col items-center relative overflow-hidden"
        >
          <div className="relative mb-4 group block">
            <div className="w-24 h-24 rounded-full bg-[#FF4D6D]/10 flex items-center justify-center text-[#FF4D6D] border-2 border-white/10 overflow-hidden relative">
              {(avatarUrlState || companion) ? (
                <img src={avatarUrlState || getAvatarUrl(companion)} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                <Heart size={32} />
              )}
              {isEditing && (
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute inset-0 bg-black/50 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 cursor-pointer transition-opacity"
                >
                  <Camera size={20} className="text-white mb-1" />
                  <span className="text-[10px] text-white font-medium uppercase tracking-wider">Change</span>
                </div>
              )}
            </div>
            <input 
              type="file" 
              accept="image/*" 
              className="hidden" 
              ref={fileInputRef} 
              onChange={handleImageUpload} 
            />
          </div>
          
          <h1 className="text-2xl font-bold text-white mb-1">{companion.name}</h1>
          <p className="text-sm text-[#FF4D6D] font-medium capitalize">{companion.personality}</p>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-[#151515] border border-white/5 rounded-3xl p-6 space-y-6"
        >
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold text-white">Edit Details</h3>
            <button 
              onClick={() => setIsEditing(!isEditing)}
              className="p-2 bg-white/5 hover:bg-white/10 rounded-full text-slate-300 transition-colors"
            >
              <Pencil size={16} />
            </button>
          </div>

          {isEditing ? (
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-slate-400 font-medium mb-2">Name</label>
                <input 
                  type="text" 
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full bg-black/50 px-4 py-3 rounded-xl border border-white/10 focus:border-[#FF4D6D] outline-none transition-all"
                />
              </div>
              <div>
                <label className="block text-sm text-slate-400 font-medium mb-2">Personality</label>
                <div className="grid grid-cols-2 gap-2">
                  {['caring', 'cute', 'shy', 'funny', 'bold'].map(p => (
                    <button
                      key={p}
                      onClick={() => setPersonality(p)}
                      className={`p-3 rounded-xl border font-medium transition-all ${
                        personality === p
                          ? 'border-[#FF4D6D] bg-[#FF4D6D]/10 text-[#FF4D6D]' 
                          : 'border-white/10 bg-white/5 text-slate-300 hover:bg-white/10'
                      }`}
                    >
                      <span className="capitalize">{p}</span>
                    </button>
                  ))}
                </div>
              </div>
              <button 
                onClick={handleSave}
                disabled={saving || !name.trim()}
                className="w-full mt-4 py-3 bg-[#FF4D6D] hover:bg-[#FF4D6D]/90 text-white rounded-xl transition-all disabled:opacity-50 font-medium flex justify-center items-center gap-2"
              >
                {saving ? <Loader2 className="animate-spin" size={18} /> : <><Save size={18} /> Save Changes</>}
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <p className="text-sm text-slate-500 mb-1">Name</p>
                <p className="text-slate-200">{companion.name}</p>
              </div>
              <div>
                <p className="text-sm text-slate-500 mb-1">Personality</p>
                <p className="text-slate-200 capitalize">{companion.personality}</p>
              </div>
            </div>
          )}
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="pt-4"
        >
          <button 
            onClick={() => {
              if (confirm('Are you sure you want to delete this companion? This cannot be undone.')) {
                onReset();
              }
            }}
            className="w-full py-4 bg-red-500/10 text-red-500 font-medium rounded-xl hover:bg-red-500/20 active:bg-red-500/30 transition-all flex items-center justify-center gap-2"
          >
            <Trash2 size={18} />
            Delete Companion
          </button>
        </motion.div>
      </main>
    </div>
  );
}
