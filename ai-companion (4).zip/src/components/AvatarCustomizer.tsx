import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Check } from 'lucide-react';
import { Companion } from '../types';
import { updateCompanion } from '../services/db';

interface AvatarCustomizerProps {
  companion: Companion;
  onClose: () => void;
  onUpdate: (updatedCompanion: Companion) => void;
}

const PRESETS = {
  skinTone: [
    { id: 'pale', name: 'Pale', color: '#ffdbac' },
    { id: 'light', name: 'Light', color: '#f1c27d' },
    { id: 'brown', name: 'Brown', color: '#e0ac69' },
    { id: 'darkBrown', name: 'Dark', color: '#8d5524' },
    { id: 'black', name: 'Black', color: '#3d2218' },
    { id: 'tanned', name: 'Tanned', color: '#d39863' },
    { id: 'yellow', name: 'Yellow', color: '#f8d25c' },
  ],
  hairstyle: [
    { id: 'shortCurly', name: 'Short Curly' },
    { id: 'shortFlat', name: 'Short Flat' },
    { id: 'longHairStraight', name: 'Long Straight' },
    { id: 'longHairCurly', name: 'Long Curly' },
    { id: 'bun', name: 'Bun' },
    { id: 'bob', name: 'Bob' },
    { id: 'shaggy', name: 'Shaggy' },
    { id: 'theCaesar', name: 'Caesar' },
  ],
  hairColor: [
    { id: 'black', name: 'Black', color: '#000000' },
    { id: 'brownDark', name: 'Dark Brown', color: '#3e2819' },
    { id: 'brown', name: 'Brown', color: '#724133' },
    { id: 'blonde', name: 'Blonde', color: '#f2bb59' },
    { id: 'blondeGolden', name: 'Golden', color: '#ebb34d' },
    { id: 'auburn', name: 'Auburn', color: '#a5442b' },
    { id: 'red', name: 'Red', color: '#e54332' },
    { id: 'silverGray', name: 'Silver', color: '#dcdcdc' },
    { id: 'pastelPink', name: 'Pink', color: '#f494a8' }
  ],
  eyes: [
    { id: 'default', name: 'Default' },
    { id: 'happy', name: 'Happy' },
    { id: 'wink', name: 'Wink' },
    { id: 'squint', name: 'Squint' },
    { id: 'surprised', name: 'Surprised' },
    { id: 'side', name: 'Side' },
  ],
  clothing: [
    { id: 'hoodie', name: 'Hoodie' },
    { id: 'shirtScoopNeck', name: 'Scoop Neck' },
    { id: 'shirtCrewNeck', name: 'Crew Neck' },
    { id: 'shirtVNeck', name: 'V Neck' },
    { id: 'blazerAndShirt', name: 'Blazer + Shirt' },
    { id: 'blazerAndSweater', name: 'Blazer + Sweater' },
    { id: 'overall', name: 'Overall' },
  ],
  clothingColor: [
    { id: 'black', name: 'Black', color: '#262e33' },
    { id: 'gray01', name: 'Gray', color: '#e6e6e6' },
    { id: 'pastry', name: 'Pastry', color: '#d2b48c' },
    { id: 'blue01', name: 'Blue', color: '#65c9ff' },
    { id: 'blue02', name: 'Dark Blue', color: '#5199e4' },
    { id: 'blue03', name: 'Deep Blue', color: '#25557c' },
    { id: 'heather', name: 'Heather', color: '#929598' },
    { id: 'pastelBlue', name: 'Pastel Blue', color: '#b1e2ff' },
    { id: 'pastelGreen', name: 'Pastel Green', color: '#a0d1b3' },
    { id: 'pastelOrange', name: 'Pastel Orange', color: '#ffb299' },
    { id: 'pastelRed', name: 'Pastel Red', color: '#ff9999' },
    { id: 'pastelYellow', name: 'Pastel Yellow', color: '#ffffb3' },
    { id: 'pink', name: 'Pink', color: '#ff488e' },
    { id: 'red', name: 'Red', color: '#ff5c5c' },
    { id: 'white', name: 'White', color: '#ffffff' },
  ],
};

export default function AvatarCustomizer({ companion, onClose, onUpdate }: AvatarCustomizerProps) {
  const [skinTone, setSkinTone] = useState(companion.skinTone || 'light');
  const [hairstyle, setHairstyle] = useState(companion.hairstyle || (companion.gender === 'boy' ? 'shortCurly' : 'longHairStraight'));
  const [hairColor, setHairColor] = useState(companion.hairColor || 'black');
  const [eyes, setEyes] = useState(companion.eyes || 'default');
  const [clothing, setClothing] = useState(companion.clothing || (companion.gender === 'boy' ? 'hoodie' : 'shirtScoopNeck'));
  const [clothingColor, setClothingColor] = useState(companion.clothingColor || 'black');
  const [glasses, setGlasses] = useState(companion.glasses || false);
  const [saving, setSaving] = useState(false);

  const previewAvatarUrl = `https://api.dicebear.com/9.x/avataaars/svg?seed=${encodeURIComponent(companion.name + companion.userId)}&top=${hairstyle}&hairColor=${hairColor}&skinColor=${skinTone}&eyes=${eyes}&clothing=${clothing}&clothingColor=${clothingColor}${glasses ? '&accessories=prescription01' : ''}&backgroundColor=b6e3f4,c0aede,d1d4f9,ffdfbf,ffd5dc`;

  const handleSave = async () => {
    setSaving(true);
    try {
      const updates = {
        skinTone,
        hairstyle,
        hairColor,
        eyes,
        clothing,
        clothingColor,
        glasses,
        avatarUrl: previewAvatarUrl,
      };
      await updateCompanion(companion.id, updates);
      onUpdate({ ...companion, ...updates });
      onClose();
    } catch (e) {
      console.error(e);
      alert('Failed to save avatar');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="w-full max-w-lg bg-[#151515] rounded-3xl border border-white/10 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden"
      >
        <div className="p-4 border-b border-white/10 flex items-center justify-between sticky top-0 bg-[#151515]/90 backdrop-blur z-10">
          <h2 className="text-lg font-semibold text-white">Customize Avatar</h2>
          <button onClick={onClose} className="p-2 bg-white/5 rounded-full hover:bg-white/10 text-slate-300">
            <X size={20} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-8 custom-scrollbar">
          <div className="flex justify-center shrink-0">
            <div className="w-40 h-40 rounded-full overflow-hidden border-4 border-[#FF4D6D]/30 shadow-lg bg-white/5 relative">
              <img src={previewAvatarUrl} alt="Avatar Preview" className="w-full h-full object-cover" />
            </div>
          </div>

          {/* Skin Tone */}
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-3">Skin Tone</label>
            <div className="flex flex-wrap gap-3">
              {PRESETS.skinTone.map(s => (
                <button
                  key={s.id}
                  title={s.name}
                  onClick={() => setSkinTone(s.id)}
                  style={{ backgroundColor: s.color }}
                  className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all shadow-sm ${skinTone === s.id ? 'border-white scale-110' : 'border-transparent hover:scale-105'}`}
                >
                  {skinTone === s.id && <Check size={16} className={['pale', 'light'].includes(s.id) ? 'text-black' : 'text-white'} />}
                </button>
              ))}
            </div>
          </div>

          {/* Hair Style Map */}
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-3">Hair Style</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {PRESETS.hairstyle.map(h => (
                <button
                  key={h.id}
                  onClick={() => setHairstyle(h.id)}
                  className={`px-3 py-2 text-xs font-medium rounded-xl border transition-all ${hairstyle === h.id ? 'border-[#FF4D6D] bg-[#FF4D6D]/10 text-white' : 'border-white/5 bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'}`}
                >
                  {h.name}
                </button>
              ))}
            </div>
          </div>

          {/* Hair Color */}
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-3">Hair Color</label>
            <div className="flex flex-wrap gap-3">
              {PRESETS.hairColor.map(c => (
                <button
                  key={c.id}
                  title={c.name}
                  onClick={() => setHairColor(c.id)}
                  style={{ backgroundColor: c.color }}
                  className={`w-8 h-8 rounded-full flex items-center justify-center border-2 transition-all shadow-sm ${hairColor === c.id ? 'border-white scale-110' : 'border-transparent hover:scale-105'}`}
                >
                  {hairColor === c.id && <Check size={14} className={['blonde', 'blondeGolden', 'silverGray'].includes(c.id) ? 'text-black' : 'text-white'} />}
                </button>
              ))}
            </div>
          </div>

          {/* Eye Color */}
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-3">Eyes</label>
            <div className="grid grid-cols-3 gap-2">
              {PRESETS.eyes.map(e => (
                <button
                  key={e.id}
                  onClick={() => setEyes(e.id)}
                  className={`px-3 py-2 text-xs font-medium rounded-xl border transition-all ${eyes === e.id ? 'border-[#FF4D6D] bg-[#FF4D6D]/10 text-white' : 'border-white/5 bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'}`}
                >
                  {e.name}
                </button>
              ))}
            </div>
          </div>

          {/* Glasses */}
          <div>
            <label className="flex items-center gap-3 cursor-pointer group">
              <div className={`w-10 h-6 rounded-full p-1 transition-colors ${glasses ? 'bg-[#FF4D6D]' : 'bg-white/10 group-hover:bg-white/20'}`}>
                <div className={`w-4 h-4 bg-white rounded-full shadow-md transition-transform ${glasses ? 'translate-x-4' : 'translate-x-0'}`} />
              </div>
              <span className="text-sm font-medium text-slate-300">Glasses</span>
            </label>
          </div>

          {/* Clothing */}
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-3">Outfit</label>
            <div className="grid grid-cols-2 gap-2">
              {PRESETS.clothing.map(c => (
                <button
                  key={c.id}
                  onClick={() => setClothing(c.id)}
                  className={`px-3 py-2 text-xs font-medium rounded-xl border transition-all ${clothing === c.id ? 'border-[#FF4D6D] bg-[#FF4D6D]/10 text-white' : 'border-white/5 bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'}`}
                >
                  {c.name}
                </button>
              ))}
            </div>
          </div>

          {/* Clothing Color */}
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-3">Outfit Color</label>
            <div className="flex flex-wrap gap-3">
              {PRESETS.clothingColor.map(c => (
                <button
                  key={c.id}
                  title={c.name}
                  onClick={() => setClothingColor(c.id)}
                  style={{ backgroundColor: c.color }}
                  className={`w-8 h-8 rounded-full flex items-center justify-center border-2 transition-all shadow-sm ${clothingColor === c.id ? 'border-[#FF4D6D] scale-110' : 'border-transparent hover:scale-105'}`}
                />
              ))}
            </div>
          </div>
        </div>

        <div className="p-4 border-t border-white/10 sticky bottom-0 bg-[#151515] flex gap-3 z-10">
          <button onClick={onClose} className="flex-1 py-3 bg-white/5 hover:bg-white/10 text-white rounded-xl font-medium transition-colors">
            Cancel
          </button>
          <button onClick={handleSave} disabled={saving} className="flex-1 py-3 bg-[#FF4D6D] hover:bg-[#FF4D6D]/90 text-white rounded-xl font-medium shadow-lg transition-colors flex justify-center items-center">
            {saving ? <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" /> : 'Save Profile'}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
