import React, { useState } from 'react';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { auth } from '../services/firebase';
import { Heart, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';

export default function Login() {
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    setLoading(true);
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error(error);
      alert('Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full h-screen flex items-center justify-center p-4 bg-gradient-to-br from-[#0a0000] to-[#140005] font-sans relative overflow-hidden">
      {/* Soft romantic ambient background glow */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#FF4D6D] rounded-full blur-[150px] opacity-10 pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#ff1a4a] rounded-full blur-[150px] opacity-10 pointer-events-none"></div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-sm bg-[#120508]/80 backdrop-blur-2xl rounded-[2rem] border border-[#FF4D6D]/10 p-8 shadow-[0_0_60px_rgba(255,77,109,0.05)] text-center relative z-10"
      >
        <motion.div 
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.3, type: 'spring', bounce: 0.5 }}
          className="mx-auto w-16 h-16 rounded-full bg-gradient-to-br from-[#FF4D6D]/20 to-[#ff1a4a]/10 border border-[#FF4D6D]/20 flex items-center justify-center mb-6 text-[#FF4D6D] shadow-[0_0_20px_rgba(255,77,109,0.2)]"
        >
          <Heart size={32} fill="currentColor" className="animate-pulse" />
        </motion.div>
        
        <h1 className="text-3xl font-semibold tracking-tight text-white mb-2 font-serif italic">Sathia</h1>
        <p className="text-sm font-light text-[#FF4D6D]/70 mb-8">Sign in to connect with your emotional companion.</p>
        
        <button 
          onClick={handleLogin}
          disabled={loading}
          className="w-full py-3.5 bg-white/5 border border-white/10 hover:bg-white/10 text-white font-medium rounded-2xl active:scale-[0.98] transition-all flex items-center justify-center gap-3 disabled:opacity-70 disabled:active:scale-100"
        >
          {loading ? (
            <Loader2 className="animate-spin text-white" size={20} />
          ) : (
            <>
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
              </svg>
              Sign in with Google
            </>
          )}
        </button>
      </motion.div>
    </div>
  );
}
