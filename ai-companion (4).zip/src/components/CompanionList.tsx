import React, { useState, useEffect } from 'react';
import { Companion } from '../types';
import { getCompanions } from '../services/db';
import { getAvatarUrl } from '../lib/avatars';
import { Plus, X, Trash2 } from 'lucide-react';
import { motion } from 'motion/react';
import Onboarding from './Onboarding';
import { deleteCompanion } from '../services/db';

interface CompanionListProps {
  onSelect: (companion: Companion) => void;
  onClose: () => void;
  currentCompanionId: string;
}

export default function CompanionList({ onSelect, onClose, currentCompanionId }: CompanionListProps) {
  const [companions, setCompanions] = useState<Companion[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);

  useEffect(() => {
    loadCompanions();
  }, []);

  const loadCompanions = async () => {
    try {
      const comps = await getCompanions();
      setCompanions(comps);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (e: React.MouseEvent, compId: string) => {
    e.stopPropagation();
    if (!confirm('Are you sure you want to delete this character?')) return;
    try {
      setLoading(true);
      await deleteCompanion(compId);
      const comps = companions.filter(c => c.id !== compId);
      setCompanions(comps);
      if (currentCompanionId === compId && comps.length > 0) {
        onSelect(comps[0]);
      } else if (comps.length === 0) {
        window.location.reload(); // Reload to trigger onboarding if all characters are deleted
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (showAdd) {
    return (
      <div className="absolute inset-0 z-50 bg-[#0F0F0F] flex flex-col">
        <div className="p-4 flex justify-between items-center border-b border-white/5 shrink-0 bg-[#151515]">
          <h2 className="text-lg font-semibold text-white">Create New Character</h2>
          <button onClick={() => setShowAdd(false)} className="p-2 rounded-full hover:bg-white/5 text-slate-300">
            <X size={20} />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto">
          <Onboarding 
            onComplete={(profile, comp) => {
              setShowAdd(false);
              onSelect(comp);
            }} 
            skipProfile={true} 
          />
        </div>
      </div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.3 }}
      className="absolute inset-0 z-50 bg-[#0f0f0f]/95 backdrop-blur-xl flex flex-col"
    >
      <div className="p-6 md:p-10 flex justify-between items-center shrink-0 max-w-6xl mx-auto w-full">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-white mb-2">Switch Character</h2>
          <p className="text-slate-400 text-sm">Select a companion to continue your journey</p>
        </div>
        <button onClick={onClose} className="p-3 bg-white/5 hover:bg-white/10 rounded-full text-white transition-colors">
          <X size={24} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-6 md:px-10 pb-20 custom-scrollbar">
        <div className="max-w-6xl mx-auto">
          {loading ? (
            <div className="flex items-center justify-center py-20">
              <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-[#FF4D6D]"></div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {/* Add New Button Card */}
              <div 
                onClick={() => setShowAdd(true)}
                className="h-[280px] rounded-3xl border-2 border-dashed border-white/10 hover:border-[#FF4D6D]/50 hover:bg-[#FF4D6D]/5 transition-all cursor-pointer flex flex-col items-center justify-center p-6 text-center gap-4 group"
              >
                <div className="w-16 h-16 rounded-full bg-white/5 group-hover:bg-[#FF4D6D]/20 flex items-center justify-center text-slate-400 group-hover:text-[#FF4D6D] transition-colors">
                  <Plus size={32} />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-lg">Create New</h3>
                  <p className="text-sm text-slate-500 mt-1">Design a completely new companion</p>
                </div>
              </div>

              {/* Character Cards */}
              {companions.map(comp => {
                const isSelected = currentCompanionId === comp.id;
                
                return (
                  <div 
                    key={comp.id}
                    onClick={() => onSelect(comp)}
                    className={`h-[280px] relative rounded-3xl overflow-hidden cursor-pointer group transition-all duration-300 ${isSelected ? 'ring-2 ring-[#FF4D6D] ring-offset-4 ring-offset-[#0f0f0f]' : 'hover:scale-[1.02] hover:shadow-xl hover:shadow-black/50'}`}
                  >
                    <img 
                      src={getAvatarUrl(comp)} 
                      alt={comp.name} 
                      className={`absolute inset-0 w-full h-full object-cover transition-transform duration-700 ${!isSelected && 'group-hover:scale-110'}`} 
                    />
                    
                    {/* Gradient Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0f0f0f] via-[#0f0f0f]/40 to-transparent"></div>
                    
                    {/* Content */}
                    <div className="absolute inset-0 p-6 flex flex-col justify-end">
                      <div className="flex justify-between items-end gap-2">
                        <div className="min-w-0">
                          <h3 className="font-bold text-2xl text-white truncate mb-1">{comp.name}</h3>
                          <div className="flex flex-wrap gap-2">
                            <span className="px-2.5 py-1 rounded-lg bg-white/10 backdrop-blur-md text-xs font-medium text-white capitalize border border-white/10">
                              {comp.role}
                            </span>
                            <span className="px-2.5 py-1 rounded-lg bg-[#FF4D6D]/20 backdrop-blur-md text-xs font-medium text-[#FF4D6D] capitalize border border-[#FF4D6D]/20">
                              {comp.personality}
                            </span>
                          </div>
                        </div>
                        <button 
                          onClick={(e) => handleDelete(e, comp.id)}
                          className="shrink-0 p-2.5 rounded-full bg-black/40 backdrop-blur-md text-white/50 hover:text-red-500 hover:bg-red-500/20 transition-colors opacity-0 group-hover:opacity-100 focus:opacity-100"
                          title="Delete Character"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                      
                      {isSelected && (
                        <div className="absolute top-4 right-4 px-3 py-1 bg-[#FF4D6D] bg-opacity-90 backdrop-blur-md text-[11px] font-bold text-white uppercase tracking-wider rounded-full">
                          Active
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
