import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, Check } from 'lucide-react';
import { UserProfile } from '../types';
import { updateUserProfile } from '../services/db';

interface PremiumProps {
  userProfile: UserProfile;
  onUpdateProfile: (profile: UserProfile) => void;
  onClose: () => void;
}

export default function Premium({ userProfile, onClose, onUpdateProfile }: PremiumProps) {
  const [loading, setLoading] = useState(false);

  const handleSubscribe = async () => {
    // In a real app we'd open Razorpay popup here.
    // We mock the successful payment flow.
    setLoading(true);
    try {
      // Simulate Razorpay delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      const profile = await updateUserProfile({ ...userProfile, isPremium: true });
      onUpdateProfile(profile);
    } catch (e) {
      console.error(e);
      alert('Payment failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm font-sans text-white">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="w-full max-w-2xl bg-[#120508] rounded-3xl border border-[#FF4D6D]/20 shadow-2xl overflow-hidden relative"
      >
        <button onClick={onClose} className="absolute top-4 right-4 p-2 bg-white/5 rounded-full hover:bg-white/10 text-white z-10 transition-colors">
          <X size={20} />
        </button>

        <div className="relative p-8 md:p-12 text-center border-b border-[#FF4D6D]/10 bg-gradient-to-br from-[#FF4D6D]/10 to-transparent overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#FF4D6D] rounded-full blur-[100px] opacity-20 pointer-events-none translate-x-1/2 -translate-y-1/2"></div>
          
          <h2 className="text-3xl font-semibold mb-2 font-serif tracking-tight">Sathia Pro</h2>
          <p className="text-[#FF4D6D]/70 mb-0">Unlock the full companion experience</p>
        </div>

        <div className="p-6 md:p-8 flex flex-col md:flex-row gap-6">
          <div className="flex-1 bg-black/40 rounded-2xl p-6 border border-white/5">
            <h3 className="text-lg font-medium mb-4 text-white/50">Free Tier</h3>
            <ul className="space-y-4">
              <li className="flex items-center gap-3 text-white/70">
                <Check size={16} className="text-[#FF4D6D]/50" /> Text chatting
              </li>
              <li className="flex items-center gap-3 text-white/70">
                <Check size={16} className="text-[#FF4D6D]/50" /> Static AI Personality
              </li>
              <li className="flex items-center gap-3 text-white/30 line-through">
                <X size={16} className="text-white/20" /> Voice messages
              </li>
              <li className="flex items-center gap-3 text-white/30 line-through">
                <X size={16} className="text-white/20" /> Avatar customization
              </li>
            </ul>
          </div>

          <div className="flex-1 bg-gradient-to-b from-[#FF4D6D]/10 to-black/40 rounded-2xl p-6 border border-[#FF4D6D]/30 relative overflow-hidden">
            <div className="absolute top-0 right-0 bg-[#FF4D6D] text-white text-xs font-bold px-3 py-1 rounded-bl-xl">POPULAR</div>
            <h3 className="text-lg font-medium mb-4 text-white">Pro Tier <span className="text-xs text-[#FF4D6D] font-normal ml-2">₹99/month</span></h3>
            <ul className="space-y-4">
              <li className="flex items-center gap-3 text-white">
                <Check size={16} className="text-[#FF4D6D]" /> Text chatting
              </li>
              <li className="flex items-center gap-3 text-white">
                <Check size={16} className="text-[#FF4D6D]" /> Dynamic AI Personality
              </li>
              <li className="flex items-center gap-3 text-white">
                <Check size={16} className="text-[#FF4D6D]" /> Real voice messages
              </li>
              <li className="flex items-center gap-3 text-white">
                <Check size={16} className="text-[#FF4D6D]" /> Premium avatar customisation
              </li>
            </ul>

            {userProfile.isPremium ? (
              <div className="mt-8 bg-green-500/10 text-green-400 py-3 rounded-xl text-center border border-green-500/20 font-medium">
                You are on Pro
              </div>
            ) : (
              <div className="mt-8 flex flex-col gap-3">
                <button 
                  onClick={handleSubscribe}
                  disabled={loading}
                  className="w-full py-3.5 bg-gradient-to-r from-[#FF4D6D] to-[#ff1a4a] hover:shadow-[0_0_20px_rgba(255,77,109,0.3)] text-white/90 rounded-xl transition-all font-medium disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {loading ? <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" /> : 'Subscribe with Razorpay'}
                </button>
                <div className="relative mt-2">
                  <input
                    type="text"
                    placeholder="Enter promo code..."
                    className="w-full bg-black/40 pl-4 pr-24 py-3 rounded-xl border border-[#FF4D6D]/10 focus:border-[#FF4D6D]/40 focus:ring-1 focus:ring-[#FF4D6D]/40 outline-none transition-all placeholder:text-white/30 text-white/90 text-sm"
                    onKeyDown={async (e) => {
                      if (e.key === 'Enter') {
                        const val = e.currentTarget.value.trim().toLowerCase();
                        if (val === 'ilovesathia') {
                          setLoading(true);
                          try {
                            const profile = await updateUserProfile({ ...userProfile, isPremium: true });
                            onUpdateProfile(profile);
                            onClose();
                          } catch (err) {
                            console.error(err);
                            e.currentTarget.value = '';
                            e.currentTarget.placeholder = 'Refresh and try again...';
                          } finally {
                            setLoading(false);
                          }
                        } else {
                          e.currentTarget.value = '';
                          e.currentTarget.placeholder = 'Invalid code';
                        }
                      }
                    }}
                  />
                  <button 
                    onClick={async (e) => {
                      const input = e.currentTarget.previousElementSibling as HTMLInputElement;
                      if (!input) return;
                      const val = input.value.trim().toLowerCase();
                      if (val === 'ilovesathia') {
                        setLoading(true);
                        try {
                          const profile = await updateUserProfile({ ...userProfile, isPremium: true });
                          onUpdateProfile(profile);
                          onClose();
                        } catch (err) {
                          console.error(err);
                          input.value = '';
                          input.placeholder = 'Refresh and try again...';
                        } finally {
                          setLoading(false);
                        }
                      } else {
                        input.value = '';
                        input.placeholder = 'Invalid code';
                      }
                    }}
                    className="absolute right-2 top-1/2 -translate-y-1/2 px-3 py-1.5 bg-[#FF4D6D]/20 hover:bg-[#FF4D6D]/30 text-[#FF4D6D] rounded-lg text-xs font-bold uppercase tracking-wider transition-colors"
                  >
                    Apply
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
