import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Loader2, User, Calendar, Sparkles } from 'lucide-react';
import { UserProfile, Companion } from '../types';
import { createCompanion, saveUserProfile, getUserProfile } from '../services/db';

interface OnboardingProps {
  onComplete: (user: UserProfile, companion: Companion) => void;
  skipProfile?: boolean;
}

export default function Onboarding({ onComplete, skipProfile = false }: OnboardingProps) {
  const [step, setStep] = useState(skipProfile ? 1 : 0);
  const [userName, setUserName] = useState('');
  const [userAge, setUserAge] = useState('21');
  const MODES: { value: string, desc: string }[] = [
    { value: 'Girlfriend', desc: 'A sweet, caring companion.' },
    { value: 'Boyfriend', desc: 'A supportive, charming companion.' },
    { value: 'Practice Girlfriend', desc: 'Practice talking to a real girl.' },
    { value: 'Practice Boyfriend', desc: 'Practice talking to a real boy.' },
    { value: 'Best Friend (Girl)', desc: 'Share stories, vent emotions.' },
    { value: 'Best Friend (Boy)', desc: 'Share stories, vent emotions.' }
  ];
  const [mode, setMode] = useState('Girlfriend');
  const [companionName, setCompanionName] = useState('');
  const [personality, setPersonality] = useState('caring');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Load from localStorage if present
  useEffect(() => {
    const savedName = localStorage.getItem('userName');
    const savedAge = localStorage.getItem('userAge');
    const savedMode = localStorage.getItem('companionMode') as 'Girlfriend' | 'Boyfriend' | null;
    const savedCompanionName = localStorage.getItem('companionName');
    
    if (savedName) setUserName(savedName);
    if (savedAge) setUserAge(savedAge);
    if (savedMode) setMode(savedMode);
    if (savedCompanionName) setCompanionName(savedCompanionName);
  }, []);

  const handleNext = () => {
    if (step === 0 && userName.trim() && userAge) {
      localStorage.setItem('userName', userName);
      localStorage.setItem('userAge', userAge);
      setStep(1);
    }
    else if (step === 1) {
      localStorage.setItem('companionMode', mode);
      setStep(2);
    }
  };

  const handleSubmit = async () => {
    if (!companionName.trim() || !personality.trim()) return;
    
    localStorage.setItem('companionName', companionName);
    localStorage.setItem('companionPersonality', personality);
    
    setLoading(true);
    try {
      let savedProfile: UserProfile | null = null;
      if (!skipProfile) {
        const userProfile: Omit<UserProfile, 'id'> = {
          name: userName.trim(),
          age: userAge,
          education: 'Default',
          createdAt: Date.now(),
        };
        savedProfile = await saveUserProfile(userProfile) as UserProfile;
      } else {
        savedProfile = await getUserProfile();
      }

      if (!savedProfile) throw new Error("User profile missing");
      
      const gender = mode.includes('Girl') ? 'girl' : mode.includes('Boy') ? 'boy' : 'other';
      
      const companionData: Omit<Companion, 'id' | 'userId' | 'createdAt' | 'updatedAt'> = {
        name: companionName.trim(),
        role: mode,
        gender: gender,
        personality: personality.trim(),
        nationality: 'Indian', // Default
        interests: 'Talking to you, late night chats',
        clothingStyle: 'Aesthetic',
        clothing: gender === 'boy' ? 'hoodie' : 'shirtScoopNeck',
        clothingColor: 'black',
        hairstyle: gender === 'boy' ? 'shortCurly' : 'longHairStraight',
        hairColor: 'black',
        skinTone: 'light',
        eyes: 'default',
        height: 'Average',
        glasses: false
      };

      const savedCompanion = await createCompanion(companionData);
      
      onComplete(savedProfile, savedCompanion as Companion);
    } catch (e: any) {
      console.error(e);
      setStep(2); 
      setErrorMsg(e?.message || 'Failed to setup profile.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full h-full flex items-center justify-center p-4 bg-gradient-to-br from-[#0a0000] to-[#140005] text-white overflow-y-auto font-sans relative">
      {/* Soft romantic ambient background glow */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#FF4D6D] rounded-full blur-[150px] opacity-10 pointer-events-none"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#ff1a4a] rounded-full blur-[150px] opacity-10 pointer-events-none"></div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-md bg-[#120508]/80 backdrop-blur-2xl rounded-[2rem] p-8 border border-[#FF4D6D]/10 shadow-[0_0_60px_rgba(255,77,109,0.05)] relative z-10"
      >
        <div className="text-center mb-8">
          <motion.div 
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.3, type: 'spring', bounce: 0.5 }}
            className="mx-auto w-14 h-14 rounded-full bg-gradient-to-br from-[#FF4D6D]/20 to-[#ff1a4a]/10 flex items-center justify-center mb-5 text-[#FF4D6D] shadow-[0_0_20px_rgba(255,77,109,0.2)] border border-[#FF4D6D]/20"
          >
            <Heart size={26} fill="currentColor" className="animate-pulse" />
          </motion.div>
          <h1 className="text-2xl md:text-3xl font-semibold tracking-tight text-white mb-2 font-serif">
            {step === 0 && "Let's get to know you"}
            {step === 1 && "Choose Your Connection"}
            {step === 2 && "Bring Them to Life"}
          </h1>
          <p className="text-[#FF4D6D]/70 text-sm md:text-base font-light">
            {step === 0 && "Before we begin this beautiful journey..."}
            {step === 1 && "Who are you looking for?"}
            {step === 2 && "Define the soul of your perfect partner."}
          </p>
        </div>

        <div className="relative min-h-[220px]">
          <AnimatePresence mode="wait">
            {step === 0 && (
              <motion.div
                key="step0"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex flex-col h-full gap-5"
              >
                <div>
                  <label className="block text-sm text-[#FF4D6D]/80 font-medium mb-3 ml-1">Your Name</label>
                  <div className="relative">
                    <User size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#FF4D6D]/50" />
                    <input 
                      type="text" 
                      value={userName}
                      onChange={(e) => setUserName(e.target.value)}
                      placeholder="What should they call you?"
                      onKeyDown={(e) => e.key === 'Enter' && userName.trim() && userAge && handleNext()}
                      className="w-full bg-black/40 pl-12 pr-4 py-4 rounded-2xl border border-[#FF4D6D]/10 focus:border-[#FF4D6D]/40 focus:ring-1 focus:ring-[#FF4D6D]/40 outline-none transition-all placeholder:text-white/20 text-white/90"
                      autoFocus
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm text-[#FF4D6D]/80 font-medium mb-3 ml-1">Your Age</label>
                  <div className="relative">
                    <Calendar size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#FF4D6D]/50" />
                    <input 
                      type="number" 
                      min="18"
                      max="100"
                      value={userAge}
                      onChange={(e) => setUserAge(e.target.value)}
                      placeholder="Your age"
                      onKeyDown={(e) => e.key === 'Enter' && userName.trim() && userAge && handleNext()}
                      className="w-full bg-black/40 pl-12 pr-4 py-4 rounded-2xl border border-[#FF4D6D]/10 focus:border-[#FF4D6D]/40 focus:ring-1 focus:ring-[#FF4D6D]/40 outline-none transition-all placeholder:text-white/20 text-white/90"
                    />
                  </div>
                </div>

                <button 
                  onClick={handleNext}
                  disabled={!userName.trim() || !userAge}
                  className="w-full py-4 mt-2 bg-gradient-to-r from-[#FF4D6D] to-[#ff1a4a] hover:shadow-[0_0_20px_rgba(255,77,109,0.3)] text-white/90 font-medium rounded-2xl transition-all disabled:opacity-40 disabled:hover:shadow-none"
                >
                  Continue
                </button>
              </motion.div>
            )}

            {step === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex flex-col h-full gap-4"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                  {MODES.map((m) => (
                    <button
                      key={m.value}
                      onClick={() => setMode(m.value)}
                      className={`relative overflow-hidden p-4 rounded-xl border transition-all duration-300 text-left w-full ${
                        mode === m.value 
                          ? 'border-[#FF4D6D] bg-[#FF4D6D]/10 shadow-[0_0_15px_rgba(255,77,109,0.1)]' 
                          : 'border-[#FF4D6D]/10 bg-black/20 text-white/60 hover:bg-black/40 hover:border-[#FF4D6D]/30'
                      }`}
                    >
                      {mode === m.value && (
                        <motion.div layoutId="mode-highlight" className="absolute inset-0 bg-gradient-to-r from-[#FF4D6D]/10 to-transparent pointer-events-none" />
                      )}
                      <div className="flex items-center gap-3 relative z-10">
                        <div className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${mode === m.value ? 'bg-gradient-to-br from-[#FF4D6D] to-[#ff1a4a] text-white' : 'bg-white/5 text-white/40'}`}>
                          <Heart size={16} fill={mode === m.value ? "currentColor" : "none"} />
                        </div>
                        <div>
                          <p className={`font-medium text-sm ${mode === m.value ? 'text-white' : 'text-white/70'}`}>{m.value}</p>
                          <p className="text-[10px] text-white/40 mt-0.5">{m.desc}</p>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>

                <div className="flex gap-3 mt-auto pt-2">
                  <button onClick={() => setStep(0)} className="px-5 py-4 bg-white/5 hover:bg-white/10 rounded-2xl text-white/70 transition-all font-medium">Back</button>
                  <button 
                    onClick={handleNext}
                    className="flex-1 py-4 bg-gradient-to-r from-[#FF4D6D] to-[#ff1a4a] hover:shadow-[0_0_20px_rgba(255,77,109,0.3)] text-white/90 rounded-2xl transition-all font-medium"
                  >
                    Continue
                  </button>
                </div>
              </motion.div>
            )}
            
            {step === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex flex-col h-full gap-5"
              >
                <div>
                  <label className="block text-sm text-[#FF4D6D]/80 font-medium mb-3 ml-1">Their Name</label>
                  <div className="relative">
                    <Sparkles size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#FF4D6D]/50" />
                    <input 
                      type="text" 
                      value={companionName}
                      onChange={(e) => setCompanionName(e.target.value)}
                      placeholder="e.g. Maya, Kabir"
                      onKeyDown={(e) => e.key === 'Enter' && companionName.trim() && handleSubmit()}
                      className="w-full bg-black/40 pl-12 pr-4 py-4 rounded-2xl border border-[#FF4D6D]/10 focus:border-[#FF4D6D]/40 focus:ring-1 focus:ring-[#FF4D6D]/40 outline-none transition-all placeholder:text-white/20 text-white/90"
                      autoFocus
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm text-[#FF4D6D]/80 font-medium mb-3 ml-1">Vibe / Personality</label>
                  <div className="grid grid-cols-3 gap-2">
                    {['Caring', 'Playful', 'Shy', 'Bold', 'Cute'].map(p => (
                      <button
                        key={p}
                        onClick={() => setPersonality(p.toLowerCase())}
                        className={`py-3 px-2 rounded-xl border text-xs font-medium transition-all ${
                          personality === p.toLowerCase() 
                            ? 'border-[#FF4D6D] bg-[#FF4D6D]/10 text-white' 
                            : 'border-[#FF4D6D]/10 bg-black/20 text-white/50 hover:bg-black/40 hover:text-white/80'
                        }`}
                      >
                        {p}
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="flex gap-3 mt-auto pt-2">
                  <button onClick={() => setStep(1)} className="px-5 py-4 bg-white/5 hover:bg-white/10 rounded-2xl text-white/70 transition-all font-medium">Back</button>
                  <div className="flex-1 flex flex-col gap-2">
                    <button 
                      onClick={handleSubmit}
                      disabled={!companionName.trim() || loading}
                      className="w-full py-4 bg-gradient-to-r from-[#FF4D6D] to-[#ff1a4a] hover:shadow-[0_0_20px_rgba(255,77,109,0.3)] text-white/90 rounded-2xl transition-all disabled:opacity-40 disabled:hover:shadow-none font-medium flex justify-center items-center gap-2"
                    >
                      {loading ? <Loader2 className="animate-spin" size={18} /> : 'Start Our Story'}
                    </button>
                    {errorMsg && <p className="text-xs text-red-400 text-center">{errorMsg}</p>}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}
