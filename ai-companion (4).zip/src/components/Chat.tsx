import React, { useState, useRef, useEffect } from 'react';
import { Companion, Message, UserProfile } from '../types';
import { generateChatResponse } from '../services/ai';
import { saveMessage, subscribeToMessages } from '../services/db';
import { Send, Eraser, Edit2, Trash2, MoreVertical, Menu, Volume2, VolumeX, Crown, Phone } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getAvatarUrl } from '../lib/avatars';
import { updateMessage, deleteMessage, clearChat } from '../services/db';
import { playTTS } from '../services/tts';
import AvatarCustomizer from './AvatarCustomizer';
import Premium from './Premium';
import VoiceCall from './VoiceCall';
import CompanionList from './CompanionList';

interface ChatProps {
  companion: Companion;
  userProfile: UserProfile;
  onUpdateProfile?: (profile: UserProfile) => void;
  onUpdateCompanion?: (companion: Companion) => void;
  messages: Message[];
  setMessages: React.Dispatch<React.SetStateAction<Message[]>>;
  onGoToProfile: () => void;
}

export default function Chat({ companion: initialCompanion, userProfile, onUpdateProfile, messages, setMessages, onGoToProfile, onUpdateCompanion }: ChatProps) {
  const [currentCompanion, setCurrentCompanion] = useState(initialCompanion);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState('');
  const [activeMessageId, setActiveMessageId] = useState<string | null>(null);
  const [showMenu, setShowMenu] = useState(false);
  const [showAvatarCustomizer, setShowAvatarCustomizer] = useState(false);
  const [showVoiceCall, setShowVoiceCall] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [showPremium, setShowPremium] = useState(false);
  const [showCompanions, setShowCompanions] = useState(false);
  const isMutedRef = useRef(isMuted);
  useEffect(() => {
    isMutedRef.current = isMuted;
  }, [isMuted]);
  const bottomRef = useRef<HTMLDivElement>(null);
  
  const avatarUrl = getAvatarUrl(currentCompanion);

  const handleEdit = async (msg: Message) => {
    if (editingMessageId === msg.id) {
       if (editingText.trim() && editingText !== msg.text) {
         try {
           setIsLoading(true);
           await updateMessage(currentCompanion.id, msg.id, editingText.trim());
         } catch (e) {
           console.error(e);
         } finally {
           setIsLoading(false);
         }
       }
       setEditingMessageId(null);
    } else {
       setEditingMessageId(msg.id);
       setEditingText(msg.text);
    }
  };

  const handleDelete = async (msgId: string) => {
    try {
      setIsLoading(true);
      await deleteMessage(currentCompanion.id, msgId);
      setActiveMessageId(null);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const [showClearConfirm, setShowClearConfirm] = useState(false);

  const handleClearChat = async () => {
    try {
      setIsLoading(true);
      await clearChat(currentCompanion.id);
      setShowMenu(false);
      setShowClearConfirm(false);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const unsubscribe = subscribeToMessages(currentCompanion.id, setMessages);
    return () => unsubscribe();
  }, [currentCompanion.id, setMessages]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  useEffect(() => {
    if (messages.length > 0 && !isLoading) {
      const lastMessage = messages[messages.length - 1];
      const HOURS_THRESHOLD = 8;
      const hoursSinceLastMessage = (Date.now() - lastMessage.createdAt) / (1000 * 60 * 60);

      const lastGreetingTime = localStorage.getItem(`lastGreeting_${currentCompanion.id}`);
      const hoursSinceLastGreeting = lastGreetingTime 
        ? (Date.now() - parseInt(lastGreetingTime)) / (1000 * 60 * 60) 
        : 999;

      if (hoursSinceLastMessage > HOURS_THRESHOLD && hoursSinceLastGreeting > 12) {
        triggerAutoGreeting();
      }
    }
  }, [messages, currentCompanion.id]);

  const triggerAutoGreeting = async () => {
    setIsLoading(true);
    try {
      localStorage.setItem(`lastGreeting_${currentCompanion.id}`, Date.now().toString());
      
      const currentHour = new Date().getHours();
      let promptHint = "It has been a long time since we talked. Send a sweet 'I missed you' text.";
      if (currentHour >= 5 && currentHour <= 10) {
        promptHint = "It is morning. Send a cute 'Good morning' text to wake them up.";
      } else if (currentHour >= 22 || currentHour <= 2) {
        promptHint = "It is late at night. Send a caring 'Good night' or 'Go to sleep' text.";
      }

      const generatedText = await generateChatResponse(
        currentCompanion, 
        userProfile, 
        messages, 
        `[SYSTEM AUTO-PROMPT: Do not answer this explicitly. Just act naturally. ${promptHint}]`
      );
      
      if (generatedText === "__QUOTA_EXCEEDED__") {
        return;
      }

      const responses = generatedText.split('|||').map(r => r.trim()).filter(Boolean);
      
      const ttsQueue: {text: string, voiceId: string, gender: string}[] = [];

      for (let i = 0; i < responses.length; i++) {
        const responseText = responses[i];
        await saveMessage(currentCompanion.id, responseText, 'model');

        if (!isMutedRef.current && userProfile.isPremium) {
          const voiceId = currentCompanion.gender === 'boy' ? 'pNInz6obpgDQGcFmaJcg' : '21m00Tcm4TlvDq8ikWAM';
          ttsQueue.push({ text: responseText, voiceId, gender: currentCompanion.gender });
        }

        if (i < responses.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 800));
        }
      }

      // Play audio sequentially in the background so it doesn't block UI
      if (ttsQueue.length > 0) {
        (async () => {
          for (const item of ttsQueue) {
            await playTTS(item.text, item.voiceId, item.gender).catch(console.error);
          }
        })();
      }
    } catch (e) {
      console.error("Auto greeting failed", e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isLoading) return;

    const userText = input.trim();
    setInput('');
    setIsLoading(true);
    setActiveMessageId(null);

    try {
      await saveMessage(currentCompanion.id, userText, 'user');
      const aiResponseText = await generateChatResponse(currentCompanion, userProfile, messages, userText);
      
      if (aiResponseText === "__QUOTA_EXCEEDED__") {
        if (window.aistudio?.openSelectKey) {
          await window.aistudio.openSelectKey();
          await saveMessage(currentCompanion.id, "Please try sending your message again now that your custom API key is set! ✨", 'model');
        }
        return;
      }

      const responses = aiResponseText.split('|||').map(r => r.trim()).filter(Boolean);

      const ttsQueue: {text: string, voiceId: string, gender: string}[] = [];

      for (let i = 0; i < responses.length; i++) {
        const responseText = responses[i];
        await saveMessage(currentCompanion.id, responseText, 'model');

        if (!isMutedRef.current && userProfile.isPremium) {
          const voiceId = currentCompanion.gender === 'boy' ? 'pNInz6obpgDQGcFmaJcg' : '21m00Tcm4TlvDq8ikWAM';
          ttsQueue.push({ text: responseText, voiceId, gender: currentCompanion.gender });
        }

        if (i < responses.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 800));
        }
      }

      // Play audio sequentially in the background so it doesn't block UI
      if (ttsQueue.length > 0) {
        (async () => {
          for (const item of ttsQueue) {
            await playTTS(item.text, item.voiceId, item.gender).catch(console.error);
          }
        })();
      }
    } catch (error) {
      console.error(error);
      alert('Failed to get a response.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen w-full bg-[#0F0F0F] mx-auto max-w-3xl">
      {/* Header */}
      <header className="h-16 px-4 md:px-6 flex items-center justify-between bg-[#151515] border-b border-white/5 shrink-0 z-20 sticky top-0">
        <div className="flex items-center gap-3 cursor-pointer" onClick={onGoToProfile}>
          <div className="w-10 h-10 rounded-full overflow-hidden shrink-0 border border-white/10">
             <img src={avatarUrl} alt={currentCompanion.name} className="w-full h-full object-cover" />
          </div>
          <div>
            <h2 className="text-[17px] font-semibold text-white tracking-tight">{currentCompanion.name}</h2>
            <p className="text-[13px] text-[#FF4D6D]">Online</p>
          </div>
        </div>
        
        <div className="flex items-center gap-1 relative">
          <button 
            onClick={() => {
              if (!userProfile.isPremium) {
                setShowPremium(true);
                return;
              }
              setShowVoiceCall(true);
            }}
            className="p-2 rounded-full hover:bg-white/5 transition-colors text-slate-300"
          >
            <Phone size={20} />
          </button>
          <button 
            onClick={() => setShowPremium(true)}
            className="p-2 rounded-full hover:bg-[#FF4D6D]/10 transition-colors text-[#FF4D6D] mr-1"
          >
            <Crown size={20} className={userProfile.isPremium ? "fill-[#FF4D6D]" : ""} />
          </button>
          <button 
            onClick={() => {
              if (!userProfile.isPremium) {
                setShowPremium(true);
                return;
              }
              setIsMuted(prev => !prev);
            }}
            className="p-2 rounded-full hover:bg-white/5 transition-colors text-slate-300"
          >
            {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
          </button>
          <button 
            onClick={() => setShowMenu(!showMenu)}
            className="p-2 -mr-2 rounded-full hover:bg-white/5 transition-colors text-slate-300"
          >
            <MoreVertical size={20} />
          </button>
          
          <AnimatePresence>
            {showMenu && (
              <motion.div 
                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                className="absolute right-0 top-12 min-w-[200px] bg-[#1a1a1a] border border-white/10 rounded-2xl shadow-xl overflow-hidden py-2 z-50"
              >
                <button 
                  onClick={() => { 
                    setShowMenu(false); 
                    setShowAvatarCustomizer(true); 
                  }}
                  className="w-full px-4 py-3 text-left text-sm text-white hover:bg-white/5 transition-colors flex items-center gap-3"
                >
                  <Edit2 size={16} /> Customize Avatar
                </button>
                <button 
                  onClick={() => { 
                    setShowMenu(false); 
                    setShowCompanions(true);
                  }}
                  className="w-full px-4 py-3 text-left text-sm text-white hover:bg-white/5 transition-colors flex items-center gap-3"
                >
                  <Menu size={16} /> Switch Character
                </button>
                <button 
                  onClick={() => { setShowMenu(false); onGoToProfile(); }}
                  className="w-full px-4 py-3 text-left text-sm text-white hover:bg-white/5 transition-colors flex items-center gap-3"
                >
                  <Menu size={16} /> View Profile
                </button>
                <button 
                  onClick={() => { setShowMenu(false); setShowClearConfirm(true); }}
                  className="w-full px-4 py-3 text-left text-sm text-red-400 hover:bg-white/5 transition-colors flex items-center gap-3"
                >
                  <Eraser size={16} /> Clear Chat
                </button>
                {typeof window !== 'undefined' && window.aistudio?.openSelectKey && (
                  <button 
                    onClick={async () => {
                      setShowMenu(false);
                      if (window.aistudio?.openSelectKey) {
                        await window.aistudio.openSelectKey();
                      }
                    }}
                    className="w-full px-4 py-3 text-left text-sm text-yellow-400 hover:bg-white/5 transition-colors flex items-center gap-3 border-t border-white/5 mt-1"
                  >
                    <Crown size={16} /> Add Custom API Key
                  </button>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </header>

      <AnimatePresence>
        {showClearConfirm && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-[#1a1a1a] rounded-3xl p-6 w-full max-w-sm border border-white/10 shadow-2xl"
            >
              <h3 className="text-xl font-semibold text-white mb-2">Clear Chat?</h3>
              <p className="text-white/60 text-sm mb-6">Are you sure you want to clear all messages? This cannot be undone.</p>
              <div className="flex gap-3">
                <button 
                  onClick={() => setShowClearConfirm(false)}
                  className="flex-1 py-3 px-4 rounded-xl bg-white/5 text-white/80 font-medium hover:bg-white/10 transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleClearChat}
                  disabled={isLoading}
                  className="flex-1 py-3 px-4 rounded-xl bg-[#FF4D6D] text-white font-medium hover:bg-[#ff1a4a] transition-colors disabled:opacity-50"
                >
                  {isLoading ? 'Clearing...' : 'Clear'}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chat Area */}
      <div 
        className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 scroll-smooth"
        onClick={() => { setActiveMessageId(null); setShowMenu(false); }}
      >
        <div className="flex flex-col items-center justify-center pt-8 pb-12 opacity-80">
          <div className="w-20 h-20 rounded-full overflow-hidden mb-4 border border-white/10">
             <img src={avatarUrl} alt={currentCompanion.name} className="w-full h-full object-cover" />
          </div>
          <p className="text-white font-medium">{currentCompanion.name}</p>
          <p className="text-sm text-slate-500 capitalize">{currentCompanion.personality}</p>
        </div>

        <AnimatePresence initial={false}>
          {messages.map((message) => {
            const isMe = message.role === 'user';
            const isActive = activeMessageId === message.id;
            
            return (
              <motion.div 
                key={message.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex flex-col w-full ${isMe ? 'items-end' : 'items-start'}`}
              >
                <div 
                  onContextMenu={(e) => { e.preventDefault(); setActiveMessageId(isActive ? null : message.id); }}
                  onClick={(e) => { e.stopPropagation(); setActiveMessageId(isActive ? null : message.id); }}
                  className={`max-w-[85%] md:max-w-[75%] px-5 py-3.5 text-[15px] leading-relaxed relative cursor-pointer select-none ${
                    isMe 
                      ? 'bg-[#FF4D6D] text-white rounded-3xl rounded-tr-sm' 
                      : 'bg-[#1e1e1e] text-slate-100 rounded-3xl rounded-tl-sm'
                  }`}
                >
                  {editingMessageId === message.id ? (
                    <div className="flex flex-col gap-3 min-w-[200px]" onClick={e => e.stopPropagation()}>
                      <textarea 
                        className="w-full bg-black/20 text-white rounded-xl p-3 text-sm focus:outline-none resize-none border border-white/10"
                        rows={3}
                        value={editingText}
                        onChange={e => setEditingText(e.target.value)}
                        autoFocus
                      />
                      <div className="flex gap-2 justify-end">
                        <button onClick={() => setEditingMessageId(null)} className="px-3 py-1.5 text-xs font-medium text-white/70 hover:text-white transition-colors">Cancel</button>
                        <button onClick={() => handleEdit(message)} className="px-3 py-1.5 text-xs font-medium bg-white text-black rounded-lg hover:bg-white/90 transition-colors">Save</button>
                      </div>
                    </div>
                  ) : (
                    <div className="whitespace-pre-wrap">{message.text}</div>
                  )}
                  {message.reaction && (
                    <div className={`absolute bottom-[-10px] ${isMe ? 'right-4' : 'left-4'} bg-[#1a1a1a] border border-white/10 rounded-full px-1.5 py-0.5 text-sm shadow-md`}>
                      {message.reaction}
                    </div>
                  )}
                </div>
                
                {isActive && editingMessageId !== message.id && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className={`flex flex-col gap-2 mt-3 px-1 ${isMe ? 'items-end' : 'items-start'}`}
                  >
                    <div className="flex gap-2 bg-[#1e1e1e] p-1.5 rounded-xl border border-white/5">
                      {['💖', '😂', '🥺', '👍', '👎'].map(emoji => (
                        <button
                          key={emoji}
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveMessageId(null);
                            updateMessage(currentCompanion.id, message.id, { 
                              reaction: message.reaction === emoji ? '' : emoji 
                            }).catch(console.error);
                          }}
                          className={`hover:bg-white/10 p-1.5 rounded-lg transition-colors ${message.reaction === emoji ? 'bg-white/20' : ''}`}
                        >
                          {emoji}
                        </button>
                      ))}
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={(e) => { e.stopPropagation(); setActiveMessageId(null); handleEdit(message); }} 
                        className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[#1e1e1e] hover:bg-[#252525] text-white rounded-xl transition-colors border border-white/5"
                      >
                        <Edit2 size={14} /> Edit
                      </button>
                      <button 
                        onClick={(e) => { e.stopPropagation(); setActiveMessageId(null); handleDelete(message.id); }} 
                        className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-red-500/10 hover:bg-red-500/20 text-red-500 rounded-xl transition-colors border border-red-500/10"
                      >
                        <Trash2 size={14} /> Delete
                      </button>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            );
          })}
        </AnimatePresence>
        
        {isLoading && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex max-w-[85%] items-start"
          >
            <div className="bg-[#1e1e1e] text-slate-100 rounded-3xl rounded-tl-sm px-5 py-4 flex gap-1.5 items-center max-w-fit">
              <span className="w-2 h-2 bg-slate-500 rounded-full animate-bounce"></span>
              <span className="w-2 h-2 bg-slate-500 rounded-full animate-bounce" style={{ animationDelay: '0.15s' }}></span>
              <span className="w-2 h-2 bg-slate-500 rounded-full animate-bounce" style={{ animationDelay: '0.3s' }}></span>
            </div>
          </motion.div>
        )}

        <div ref={bottomRef} className="h-4" />
      </div>

      {/* Input Area */}
      <div className="p-4 bg-[#0F0F0F] shrink-0 z-20 pb-safe">
        <form onSubmit={handleSend} className="relative flex items-end w-full">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Type a message..."
            disabled={isLoading}
            rows={1}
            className="w-full bg-[#1e1e1e] text-white rounded-3xl pl-5 pr-14 py-4 min-h-[56px] max-h-32 focus:outline-none disabled:opacity-50 transition-all text-[15px] resize-none overflow-y-auto block border border-transparent focus:border-white/10 scrollbar-hide"
            style={{
              height: input ? `${Math.min(128, Math.max(56, input.split('\n').length * 24 + 32))}px` : '56px'
            }}
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className={`absolute right-2 bottom-2 p-3 rounded-full transition-all flex items-center justify-center ${
              input.trim() 
                ? 'bg-[#FF4D6D] text-white' 
                : 'bg-transparent text-slate-500'
            } disabled:opacity-50`}
          >
            <Send size={20} className={input.trim() ? "translate-x-[1px] translate-y-[1px]" : ""} />
          </button>
        </form>
      </div>

      <AnimatePresence>
        {showCompanions && (
          <CompanionList 
            currentCompanionId={currentCompanion.id}
            onClose={() => setShowCompanions(false)}
            onSelect={(comp) => {
              setCurrentCompanion(comp);
              onUpdateCompanion?.(comp);
              setShowCompanions(false);
            }}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showAvatarCustomizer && (
          <AvatarCustomizer 
            companion={currentCompanion} 
            onClose={() => setShowAvatarCustomizer(false)} 
            onUpdate={(companion) => {
              setCurrentCompanion(companion);
              onUpdateCompanion?.(companion);
            }}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showPremium && (
          <Premium 
            userProfile={userProfile} 
            onClose={() => setShowPremium(false)}
            onUpdateProfile={(p) => {
              onUpdateProfile?.(p);
            }}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showVoiceCall && (
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed inset-0 z-50 bg-[#0F0F0F]"
          >
            <VoiceCall 
              companion={currentCompanion} 
              userProfile={userProfile} 
              onEndCall={() => setShowVoiceCall(false)} 
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
