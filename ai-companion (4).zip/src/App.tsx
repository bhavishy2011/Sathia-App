import React, { useState, useEffect } from 'react';
import { Companion, Message, UserProfile } from './types';
import Chat from './components/Chat';
import Profile from './components/Profile';
import Login from './components/Login';
import Onboarding from './components/Onboarding';
import { auth } from './services/firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { getCompanions, deleteCompanion, getUserProfile } from './services/db';
import { Loader2 } from 'lucide-react';

type View = 'chat' | 'profile';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authInitialized, setAuthInitialized] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [companion, setCompanion] = useState<Companion | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentView, setCurrentView] = useState<View>('chat');
  const [loadingApp, setLoadingApp] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      setAuthInitialized(true);
      if (u) {
        try {
          const profile = await getUserProfile();
          setUserProfile(profile);

          if (profile) {
            const comps = await getCompanions();
            if (comps.length > 0) {
              setCompanion(comps[0]);
              setCurrentView('chat');
            } else {
              setCompanion(null);
            }
          }
        } catch (error) {
          console.error(error);
        }
      }
      setLoadingApp(false);
    });
    return unsub;
  }, []);

  const handleReset = async () => {
    if (companion) {
      try {
        await deleteCompanion(companion.id);
        setCompanion(null);
        setMessages([]);
      } catch (e) {
        alert('Failed to delete companion');
      }
    }
  };

  if (!authInitialized || loadingApp) {
    return <div className="min-h-screen bg-[#0F0F0F] text-slate-100 flex items-center justify-center font-sans tracking-widest uppercase text-sm animate-pulse">Initializing...</div>;
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0F0F0F] text-slate-100 flex overflow-hidden font-sans relative">
         <div className="flex-1 flex justify-center w-full z-10 relative">
            <Login />
         </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-[#0F0F0F] text-white flex flex-col overflow-hidden font-sans selection:bg-[#FF4D6D]/20 transition-colors duration-1000">
      <div className="flex-1 relative z-10 overflow-hidden flex flex-col">
        {(!userProfile || !companion) && (
           <div className="flex justify-center h-full">
             <Onboarding onComplete={(profile, comp) => {
               setUserProfile(profile);
               setCompanion(comp);
               setCurrentView('chat');
             }} />
           </div>
        )}
        
        {userProfile && companion && currentView === 'profile' && (
          <Profile companion={companion} onBack={() => setCurrentView('chat')} onReset={handleReset} />
        )}

        {userProfile && companion && currentView === 'chat' && (
          <Chat 
            companion={companion} 
            userProfile={userProfile}
            onUpdateProfile={setUserProfile}
            onUpdateCompanion={setCompanion}
            messages={messages} 
            setMessages={setMessages} 
            onGoToProfile={() => setCurrentView('profile')} 
          />
        )}
      </div>
    </div>
  );
}
