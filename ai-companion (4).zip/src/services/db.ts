import { collection, doc, setDoc, getDocs, deleteDoc, query, orderBy, limit, onSnapshot, getDoc, where } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from './firebase';
import { UserProfile, Companion, Message } from '../types';

export async function updateUserProfile(updates: Partial<UserProfile> & { id?: string }) {
  if (!auth.currentUser) throw new Error('User not logged in');
  const userId = auth.currentUser.uid;
  const path = `users/${userId}/profile/data`;
  
  try {
    const docRef = doc(db, path);
    const snap = await getDoc(docRef);
    if(snap.exists()) {
      const data = snap.data();
      const { id, ...cleanUpdates } = updates;
      const updatedData = { ...data, ...cleanUpdates };
      await setDoc(docRef, updatedData);
      return { id: docRef.id, ...updatedData } as UserProfile;
    }
    return {} as UserProfile;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
    return {} as UserProfile;
  }
}

export async function getUserProfile() {
  if (!auth.currentUser) throw new Error('User not logged in');
  const userId = auth.currentUser.uid;
  const path = `users/${userId}/profile/data`;
  try {
    const snap = await getDoc(doc(db, path));
    return snap.exists() ? (snap.data() as UserProfile) : null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
    throw error;
  }
}

export async function saveUserProfile(profile: Omit<UserProfile, 'createdAt'>) {
  if (!auth.currentUser) throw new Error('User not logged in');
  const userId = auth.currentUser.uid;
  const path = `users/${userId}/profile/data`;
  const data: UserProfile = { ...profile, createdAt: Date.now() };
  try {
    await setDoc(doc(db, path), data);
    return data;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    throw error;
  }
}

export async function createCompanion(companion: Omit<Companion, 'id' | 'userId' | 'createdAt' | 'updatedAt'>) {
  if (!auth.currentUser) throw new Error('User not logged in');
  const userId = auth.currentUser.uid;
  const companionRef = doc(collection(db, 'users', userId, 'companions'));
  
  const newCompanion: Companion = {
    ...companion,
    id: companionRef.id,
    userId,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  
  const path = `users/${userId}/companions/${companionRef.id}`;
  try {
    await setDoc(companionRef, newCompanion);
    return newCompanion;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    throw error;
  }
}

export async function getCompanions(): Promise<Companion[]> {
  if (!auth.currentUser) throw new Error('User not logged in');
  const userId = auth.currentUser.uid;
  const path = `users/${userId}/companions`;
  try {
    const q = query(
      collection(db, path),
      where('userId', '==', userId)
    );
    const snaps = await getDocs(q);
    return snaps.docs.map(doc => doc.data() as Companion);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    throw error;
  }
}

export async function updateCompanion(companionId: string, updates: Partial<Companion>) {
  if (!auth.currentUser) throw new Error('User not logged in');
  const userId = auth.currentUser.uid;
  const path = `users/${userId}/companions/${companionId}`;
  try {
    const docRef = doc(db, path);
    const snap = await getDoc(docRef);
    if(snap.exists()) {
      const existing = snap.data() as Companion;
      await setDoc(docRef, { ...existing, ...updates, updatedAt: Date.now() });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
    throw error;
  }
}

export async function deleteCompanion(companionId: string) {
  if (!auth.currentUser) throw new Error('User not logged in');
  const userId = auth.currentUser.uid;
  const path = `users/${userId}/companions/${companionId}`;
  try {
    await deleteDoc(doc(db, path));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
    throw error;
  }
}

export async function saveMessage(companionId: string, text: string, role: 'user' | 'model') {
  if (!auth.currentUser) throw new Error('User not logged in');
  const userId = auth.currentUser.uid;
  const messageRef = doc(collection(db, 'users', userId, 'companions', companionId, 'messages'));
  
  const newMessage: Message = {
    id: messageRef.id,
    userId,
    role,
    text,
    timestamp: Date.now(),
    createdAt: Date.now(),
  };
  
  const path = `users/${userId}/companions/${companionId}/messages/${messageRef.id}`;
  try {
    await setDoc(messageRef, newMessage);
    return newMessage;
  } catch(error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    throw error;
  }
}

export async function updateMessage(companionId: string, messageId: string, updates: Partial<Pick<Message, 'text' | 'reaction'>>) {
  if (!auth.currentUser) throw new Error('User not logged in');
  const userId = auth.currentUser.uid;
  const path = `users/${userId}/companions/${companionId}/messages/${messageId}`;
  try {
    const docRef = doc(db, path);
    // Since we need to pass full valid message per rule
    const snap = await getDoc(docRef);
    if(snap.exists()) {
      const data = snap.data();
      const updatedData = { ...data };
      if (updates.text !== undefined) updatedData.text = updates.text;
      if (updates.reaction !== undefined) updatedData.reaction = updates.reaction;
      await setDoc(docRef, updatedData);
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
    throw error;
  }
}

export async function deleteMessage(companionId: string, messageId: string) {
  if (!auth.currentUser) throw new Error('User not logged in');
  const userId = auth.currentUser.uid;
  const path = `users/${userId}/companions/${companionId}/messages/${messageId}`;
  try {
    await deleteDoc(doc(db, path));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
    throw error;
  }
}

export async function clearChat(companionId: string) {
  if (!auth.currentUser) throw new Error('User not logged in');
  const userId = auth.currentUser.uid;
  const path = `users/${userId}/companions/${companionId}/messages`;
  let isQuerying = true;
  try {
    const q = query(collection(db, path));
    const snaps = await getDocs(q);
    isQuerying = false;
    for (const docSnap of snaps.docs) {
      await deleteDoc(doc(db, path, docSnap.id));
    }
  } catch (error) {
    handleFirestoreError(error, isQuerying ? OperationType.LIST : OperationType.DELETE, path);
    throw error;
  }
}
export function subscribeToMessages(companionId: string, callback: (messages: Message[]) => void) {
  if (!auth.currentUser) return () => {};
  const userId = auth.currentUser.uid;
  
  const path = `users/${userId}/companions/${companionId}/messages`;
  // We removed orderBy and limit from the query to avoid Firebase Composite Index requirement errors.
  // Instead, we will fetch all messages for this specific companion and sort them locally.
  const q = query(
    collection(db, path),
    where('userId', '==', userId)
  );
  
  return onSnapshot(q, (snapshot) => {
    // sort chronologically
    let msgs = snapshot.docs.map(d => d.data() as Message);
    msgs.sort((a, b) => a.createdAt - b.createdAt);
    
    // get last 20 messages
    if (msgs.length > 20) {
      msgs = msgs.slice(msgs.length - 20);
    }
    
    callback(msgs);
  }, (error) => {
    handleFirestoreError(error, OperationType.LIST, path);
  });
}
