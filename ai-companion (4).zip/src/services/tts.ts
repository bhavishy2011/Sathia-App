export async function playTTS(text: string, voiceId: string, gender: string = 'girl') {
  const apiKey = (import.meta as any).env.VITE_ELEVENLABS_API_KEY;
  
  const cleanText = text
    .replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{2702}-\u{27B0}\u{24C2}-\u{1F251}]/gu, '')
    .replace(/\*.*?\*/g, '') // Remove action text like *laughs*
    .replace(/\.{2,}/g, '.') // Replace ellipses with a single dot to reduce lag
    .replace(/[~_]/g, '')
    .trim();

  if (!cleanText) return null;

  if (!apiKey || apiKey === 'YOUR_API_KEY') {
    console.warn("No valid ElevenLabs API key found. Using browser TTS fallback.");
    return fallbackTTS(cleanText, gender);
  }

  try {
    const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'xi-api-key': apiKey,
      },
      body: JSON.stringify({
        text: cleanText,
        model_id: 'eleven_multilingual_v2',
        voice_settings: {
          stability: 0.3,
          similarity_boost: 0.8,
          style: 0.2, // Increases expressiveness if supported
          use_speaker_boost: true
        }
      })
    });

    if (!response.ok) {
      console.warn("ElevenLabs API key is invalid or quota exceeded. Using browser TTS fallback.");
      return fallbackTTS(text, gender);
    }

    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const audio = new Audio(url);
    
    return new Promise((resolve) => {
      audio.onended = () => resolve(audio);
      audio.onerror = () => resolve(audio);
      audio.play().catch((e) => {
        console.error("Audio play failed:", e);
        resolve(audio);
      });
    });
  } catch (error) {
    console.error("TTS playback error:", error);
    return fallbackTTS(text, gender);
  }
}

function fallbackTTS(text: string, gender: string) {
  if (!('speechSynthesis' in window)) {
    console.warn("Browser logic: speechSynthesis not supported");
    return null;
  }
  
  const utterance = new SpeechSynthesisUtterance(text);
  
  const voices = window.speechSynthesis.getVoices();
  let selectedVoice = voices.find(v => 
    v.lang.startsWith('hi-') || v.lang.startsWith('en-IN')
  );
  
  if (gender === 'girl' || gender === 'women') {
    selectedVoice = voices.find(v => (v.lang.startsWith('hi-') || v.lang.startsWith('en-IN')) && v.name.toLowerCase().includes('female')) || selectedVoice;
  } else {
    selectedVoice = voices.find(v => (v.lang.startsWith('hi-') || v.lang.startsWith('en-IN')) && v.name.toLowerCase().includes('male')) || selectedVoice;
  }
  
  if (selectedVoice) {
    utterance.voice = selectedVoice;
  }
  
  // Clean up text for TTS
  utterance.text = text.replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{2702}-\u{27B0}\u{24C2}-\u{1F251}]/gu, '');
  
  return new Promise((resolve) => {
    utterance.onend = () => resolve(utterance);
    utterance.onerror = () => resolve(utterance);
    window.speechSynthesis.speak(utterance);
  });
}
