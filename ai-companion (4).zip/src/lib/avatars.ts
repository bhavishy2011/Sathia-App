import { Companion } from '../types';

export const getAvatarUrl = (companion: Companion) => {
  if (companion.avatarUrl) return companion.avatarUrl;
  
  const g = companion.gender === 'boy' ? 'men' : 'women';
  
  // Create a hash from the companion name and userId
  const stringToHash = `${companion.name}-${companion.userId}`;
  let hash = 0;
  for (let i = 0; i < stringToHash.length; i++) {
    hash = (hash << 5) - hash + stringToHash.charCodeAt(i);
    hash |= 0;
  }
  
  const index = Math.abs(hash);

  // High quality Unsplash URLs
  const womenUnsplashIds = [
    '1534528741775-53994a69daeb', '1524504388940-b1c1722653e1', '1517841905240-472988babdf9',
    '1531746020798-e6953c6e8e04', '1503185912284-5271ff81b9a8', '1494790108377-be9c29b29330',
    '1517365830460-955ce3ccd263', '1534528741775-53994a69daeb', '1529626455594-4ff0802cfb7e',
    '1508214751196-bcfd4ca60f91', '1488426862026-3ee34a7d66bf', '1520155050868-bfae7e6015b6',
    '1515206894565-d72bfa03517c', '1492106087820-71f1a00d2b11', '1544005313-94ddf0286df2',
    '1500917293891-ef795e70e1f6', '1492447166138-5cb35c0b4c73', '1541823709867-1b206113eafd'
  ];

  const menUnsplashIds = [
    '1506794778202-cad84cf45f1d', '1543610892-0b1f7e6d8c1c', '1504257432389-52343af065f6',
    '1500648767791-00dcc994a43e', '1463453091185-61582044d556', '1507081323647-4d250478b849',
    '1519085360753-af0119f7cbe7', '1501196354995-cbb51c65aaea', '1513956589380-bad6acb9b9d4',
    '1539571696357-5a69c17a67c6', '1531427186611-ecfd6d936c79', '1480455624313-e23b44ce0240'
  ];

  if (g === 'women') {
    const id = womenUnsplashIds[index % womenUnsplashIds.length];
    return `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=400&h=400&q=80`;
  } else {
    const id = menUnsplashIds[index % menUnsplashIds.length];
    return `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=400&h=400&q=80`;
  }
};

